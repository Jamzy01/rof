# Rust Object Format Macros

Refer to the main crate [rof-rs](https://crates.io/crates/rof-rs), which includes this macros crate itself and all other functionality.